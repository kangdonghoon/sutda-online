# 섯다 온라인

친구들과 링크 하나로 같이 하는 2장 섯다예요. 칩은 가짜예요.

- **서버가 딜러**: 셔플, 패 보관, 족보 판정을 모두 서버가 해요. 각 플레이어는 자기 패만 받아요.
- **계정**: 아이디·비밀번호로 가입해요. 칩, 판수, 승수, 최고 판돈이 DB에 저장돼요.
- **랭킹**: 입장 화면에 수익 순 랭킹이 보여요. 수익 = 현재 칩 − 받은 칩(가입 + 충전).
- **관리자 페이지**: `/admin`에서 회원 칩 수정, 계정 정지, 열린 방 닫기를 할 수 있어요.

## 구성

```
server.js            HTTP 서버 · 계정/세션 · 방 관리 · 게임 루프 · SSE 푸시 · 관리자 API
store.js             저장소 (DATABASE_URL 있으면 Postgres, 없으면 메모리)
public/core.js       섯다 규칙 엔진 (서버·브라우저 공용)
public/index.html    게임 화면
public/app.js        게임 클라이언트
public/admin.html    관리자 페이지
test/                규칙 엔진·저장소 테스트
```

## 배포: Render + Neon

### 1. Neon에서 DB 만들기
1. neon.com에 가입해요. GitHub 로그인이면 돼요.
2. **New Project**를 만들어요.
   - 이름: 아무거나 (예: `sutda`)
   - Region: **AWS Asia Pacific (Singapore)**. Render를 싱가포르로 했다면 같은 곳이 빨라요.
3. 프로젝트 대시보드에서 **Connect**를 누르고 연결 문자열을 복사해요. 이렇게 생겼어요.
   ```
   postgresql://neondb_owner:비밀번호@ep-xxxx-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
   ```
   이 문자열에는 비밀번호가 들어 있어요. **GitHub에 올리거나 남에게 보여주지 마세요.**

### 2. Render에 환경변수 넣기
Render 서비스 화면 → **Environment** → **Add Environment Variable**에서 두 개를 넣어요.

| Key | Value |
|---|---|
| `DATABASE_URL` | Neon에서 복사한 연결 문자열 |
| `ADMIN_USERS` | 관리자로 쓸 **아이디**. 여러 명이면 쉼표로 (예: `donghun,minsu`) |

저장하면 Render가 다시 배포해요. 테이블(`users`, `sessions`)은 서버가 시작할 때 자동으로 만들어져요.

Render 설정은 **Language: Node**, **Build Command: `npm install`**, **Start Command: `npm start`**여야 해요. `pg` 패키지를 설치해야 하기 때문이에요.

### 3. 확인
- 로그에 `섯다 서버 실행 중 ... (저장소: postgres, 관리자: donghun)`이 보이면 성공이에요.
- `https://<주소>/healthz`가 `"db":"postgres"`를 보여줘야 해요. `"memory"`로 나오면 `DATABASE_URL`이 안 들어간 거예요.
- 사이트에서 `ADMIN_USERS`에 적은 아이디로 가입하면, 입장 화면에 **관리자** 버튼이 생겨요.

`DB 연결 실패`가 뜨고 서버가 꺼지면 연결 문자열이 틀린 거예요. 앞뒤 공백이나 따옴표가 들어가지 않았는지 확인하세요.

## 로컬 실행

```bash
npm install
node server.js                                  # DB 없이: 메모리 저장 (끄면 사라짐)
DATABASE_URL="postgresql://..." ADMIN_USERS=donghun node server.js   # Neon에 연결
```

Windows PowerShell에서는 이렇게 해요.
```powershell
$env:DATABASE_URL="postgresql://..."; $env:ADMIN_USERS="donghun"; node server.js
```

## 노는 법
1. 회원가입이나 로그인을 해요.
2. **방 만들기**를 누르고 **초대 링크 복사**로 링크를 친구에게 보내요.
3. 친구가 링크를 열면, 로그인하거나 가입하자마자 그 방으로 들어와요.
4. 방장이 **게임 시작**을 누르면 시작이에요. 사람이 모자라면 **봇 추가**로 채울 수 있어요.

칩이 판돈보다 적어지면 **칩 충전**으로 다시 10,000을 받을 수 있어요. 충전 횟수는 랭킹 수익 계산에 반영돼요.

## 동작 규칙
- **칩 저장 시점**: 판이 끝날 때, 방에서 나갈 때, 충전할 때, 관리자가 수정할 때 저장돼요.
- **한 계정은 한 방에만** 앉을 수 있어요. 다른 방에 들어가면 이전 방에서 자동으로 빠져요. 이전 방에서 판이 진행 중이면 그 판이 끝난 뒤에 옮길 수 있어요.
- **판 도중에 나가면** 내 차례일 땐 바로 다이 처리되고, 그 판이 끝나면 자리에서 빠져요.
- **관리자가 칩을 바꾸는 건** 그 사람이 진행 중인 판에 살아 있지 않을 때만 돼요.
- **계정을 정지하면** 바로 로그아웃되고 방에서 빠지며, 다시 로그인할 수 없어요.
- **비밀번호**는 scrypt로 해시해서 저장하고, 원문은 저장하지 않아요. 로그인은 30일 동안 유지돼요.
- **방 자체는 메모리에만** 있어서 서버가 재시작하면 사라져요. 계정과 칩은 DB에 남아요.

## 테스트

```bash
npm test     # 족보 단위 테스트 + 무작위 1.8만 판 시뮬레이션 + 저장소(메모리) 테스트
```

## 한계와 다음 단계
- 비밀번호 찾기 기능은 없어요. 필요하면 관리자가 DB에서 직접 처리해야 해요.
- Neon 무료 플랜은 쓰지 않으면 쉬다가 다음 요청에 다시 깨어나요. 첫 로그인이 아주 살짝 느릴 수 있어요.
- 소셜 로그인(카카오·구글)은 OAuth 앱 등록이 필요해서 넣지 않았어요.

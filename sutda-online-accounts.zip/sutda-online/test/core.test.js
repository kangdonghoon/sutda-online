const S = require('../public/core.js');
const assert = require('assert');
// 카드 번호: 월 m의 특수패 = (m-1)*2, 피 = (m-1)*2+1
const sp = m => (m - 1) * 2, pi = m => (m - 1) * 2 + 1;
const E = cs => S.evalHand(cs).name;

assert.equal(E([sp(3), sp(8)]), '38광땡');
assert.equal(E([sp(1), sp(8)]), '18광땡');
assert.equal(E([sp(1), sp(3)]), '13광땡');
assert.equal(E([sp(1), pi(3)]), '4끗');
assert.equal(E([sp(10), pi(10)]), '장땡');
assert.equal(E([sp(1), pi(1)]), '1땡');
assert.equal(E([pi(1), pi(2)]), '알리');
assert.equal(E([pi(1), sp(4)]), '독사');
assert.equal(E([pi(9), pi(1)]), '구삥');
assert.equal(E([pi(1), pi(10)]), '장삥');
assert.equal(E([pi(4), pi(10)]), '장사');
assert.equal(E([pi(4), pi(6)]), '세륙');
assert.equal(E([pi(5), pi(4)]), '갑오');
assert.equal(E([pi(2), pi(8)]), '망통');
assert.equal(E([sp(4), sp(7)]), '암행어사');
assert.equal(E([pi(4), sp(7)]), '1끗');
assert.equal(E([sp(3), sp(7)]), '땡잡이');
assert.equal(E([pi(3), sp(7)]), '망통');
assert.equal(E([sp(4), sp(9)]), '멍텅구리구사');
assert.equal(E([pi(4), sp(9)]), '구사');

// 암행어사가 18광땡을 잡음
let r = S.pickWinners(['a', 'b'], { a: [sp(4), sp(7)], b: [sp(1), sp(8)] });
assert.deepEqual(r.winners, ['a']); assert.equal(r.catchBy, '암행어사');
// 38광땡은 못 잡음
r = S.pickWinners(['a', 'b'], { a: [sp(4), sp(7)], b: [sp(3), sp(8)] });
assert.deepEqual(r.winners, ['b']);
// 땡잡이가 9땡을 잡음, 장땡은 못 잡음
r = S.pickWinners(['a', 'b'], { a: [sp(3), sp(7)], b: [sp(9), pi(9)] });
assert.deepEqual(r.winners, ['a']);
r = S.pickWinners(['a', 'b'], { a: [sp(3), sp(7)], b: [sp(10), pi(10)] });
assert.deepEqual(r.winners, ['b']);
// 구사: 상대가 알리 이하면 재경기, 땡이면 아님
assert.ok(S.checkRedeal(['a', 'b'], { a: [pi(4), pi(9)], b: [pi(1), pi(2)] }));
assert.equal(S.checkRedeal(['a', 'b'], { a: [pi(4), pi(9)], b: [sp(2), pi(2)] }), null);
// 멍구사: 장땡까지 재경기, 광땡이면 아님
assert.ok(S.checkRedeal(['a', 'b'], { a: [sp(4), sp(9)], b: [sp(10), pi(10)] }));
assert.equal(S.checkRedeal(['a', 'b'], { a: [sp(4), sp(9)], b: [sp(1), sp(8)] }), null);
// 무승부 분배
r = S.settle({ a: 500, b: 500 }, ['a', 'b'], { a: [pi(2), pi(3)], b: [sp(2), sp(3)] });
assert.deepEqual(r.pay, { a: 500, b: 500 });
// 사이드팟: a 올인 100, b·c 각 500. a 최강
r = S.settle({ a: 100, b: 500, c: 500 }, ['a', 'b', 'c'], { a: [sp(3), sp(8)], b: [sp(10), pi(10)], c: [pi(2), pi(3)] });
assert.deepEqual(r.pay, { a: 300, b: 800 });

// ── 시뮬레이션: 무작위 게임 수천 판, 칩 보존과 무한루프 없음 확인
let seed = 7; const rng = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
let hands = 0, redeals = 0, folds = 0, shows = 0;
for (let g = 0; g < 300; g++) {
  const G = S.createGame({ ante: 100, startChips: 3000 });
  const n = 2 + (g % 5);
  for (let i = 0; i < n; i++) S.addPlayer(G, 'p' + i, 'P' + i, true);
  const total = () => G.players.reduce((s, p) => s + p.chips, 0) + (G.hand && G.phase === 'bet' ? G.hand.pot : 0)
    + (G.hand && G.phase === 'show' && G.hand.result.type === 'redeal' ? G.hand.pot : 0);
  const T0 = total();
  for (let k = 0; k < 60 && S.canStart(G); k++) {
    S.startHand(G, rng, 0); hands++;
    let steps = 0;
    while (true) {
      if (G.phase === 'bet') {
        const id = G.hand.toAct; assert.ok(id, 'toAct missing');
        const kind = rng() < 0.05 ? null : S.botDecide(G, id, rng);
        const ok = kind ? S.act(G, id, kind, 0) : S.autoAct(G, 0);
        assert.ok(ok, 'illegal ' + kind + ' ' + JSON.stringify(S.legal(G, id)));
      } else if (G.phase === 'show' && G.hand.result.type === 'redeal') { redeals++; S.redeal(G, rng, 0); }
      else break;
      assert.ok(++steps < 500, 'loop');
      assert.equal(total(), T0, 'chips not conserved mid-hand');
      assert.ok(JSON.stringify(S.publicState(G, 0)).length < 3500, 'state too big');
    }
    G.hand.result.type === 'fold' ? folds++ : shows++;
    assert.equal(total(), T0, 'chips not conserved');
    G.players.forEach(p => assert.ok(p.chips >= 0));
  }
}
console.log('ok', { hands, redeals, folds, shows });
